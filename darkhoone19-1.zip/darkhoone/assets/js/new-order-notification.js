jQuery(document).ready(function($) {
    let lastOrderId = newOrderData.new_order_id;

    if (lastOrderId > 0) {
        showNotification(lastOrderId);
    }

    setInterval(function() {
        $.ajax({
            url: newOrderData.ajax_url,
            type: 'POST',
            data: {
                action: 'check_new_order'
            },
            success: function(response) {
                if (response.success && response.data.order_id > 0 && response.data.order_id !== lastOrderId) {
                    lastOrderId = response.data.order_id;
                    showNotification(response.data.order_id, response.data.message);
                }
            },
            error: function() {
                console.log('خطا در چک کردن سفارش جدید');
            }
        });
    }, 10000);

    function showNotification(orderId, message = '') {
        const notification = $('<div class="order-notification"></div>')
            .text(message || 'سفارش جدید با شماره ' + orderId + ' ثبت شد!')
            .appendTo('body');

        // پخش صدای بلندتر
        if ('AudioContext' in window || 'webkitAudioContext' in window) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            const context = new AudioContext();
            const oscillator = context.createOscillator();
            const gainNode = context.createGain();

            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(800, context.currentTime);
            gainNode.gain.setValueAtTime(1, context.currentTime);
            oscillator.connect(gainNode);
            gainNode.connect(context.destination);
            oscillator.start();
            oscillator.stop(context.currentTime + 0.5);
        }

        setTimeout(function() {
            notification.fadeOut(500, function() {
                $(this).remove();
            });
        }, 5000);
    }
});