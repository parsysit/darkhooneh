jQuery(document).ready(function($) {
    console.log('Simple Dashboard JS Loaded'); // برای دیباگ

    // تغییر وضعیت
    $(document).on('change', '.order-status-select', function() {
        var $select = $(this);
        var order_id = $select.data('order_id');
        var status = $select.val();
        var current_status = $select.find('option[selected]').val();
        var $row = $select.closest('tr');

        $.ajax({
            url: simpleDashboard.ajax_url,
            type: 'POST',
            data: {
                action: 'update_order_status',
                order_id: order_id,
                status: status,
                nonce: simpleDashboard.nonce
            },
            success: function(response) {
                if (response.success) {
                    $select.find('option').removeAttr('selected');
                    $select.find('option[value="' + status + '"]').attr('selected', 'selected');
                    $row.find('td:nth-child(6)').text(response.data.status_name);
                    if (response.data.is_completed) {
                        $row.fadeOut(300, function() {
                            $(this).remove();
                        });
                    } else {
                        alert(response.data.message);
                    }
                } else {
                    alert(response.data.message);
                    $select.val(current_status);
                }
            },
            error: function() {
                alert('خطا در ارتباط با سرور!');
                $select.val(current_status);
            }
        });
    });

    // باز کردن مودال جزئیات سفارش
    $(document).on('click', '.order-details-link', function(e) {
        e.preventDefault();
        var order_id = $(this).data('order_id');

        $.ajax({
            url: simpleDashboard.ajax_url,
            type: 'POST',
            data: {
                action: 'get_order_details',
                order_id: order_id,
                nonce: simpleDashboard.details_nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#order-details-content').html(response.data.content);
                    $('#order-details-modal').fadeIn();
                } else {
                    alert(response.data.message);
                }
            },
            error: function() {
                alert('خطا در بارگذاری جزئیات سفارش!');
            }
        });
    });

    // بستن مودال
    $('.close-modal').on('click', function() {
        $('#order-details-modal').fadeOut();
    });

    // بستن با کلیک بیرون مودال
    $(window).on('click', function(e) {
        if (e.target.id === 'order-details-modal') {
            $('#order-details-modal').fadeOut();
        }
    });

    // پرینت
    $('#print-order-btn').on('click', function() {
        var printContents = $('#order-details-content').html();
        var originalContents = $('body').html();
        $('body').html(printContents);
        window.print();
        $('body').html(originalContents);
        location.reload();
    });
});