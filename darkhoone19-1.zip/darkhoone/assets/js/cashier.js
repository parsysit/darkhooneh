// assets/js/cashier.js
jQuery(document).ready(function($) {
    // مدیریت تب‌ها
    $('.tab-button').click(function() {
        $('.tab-button').removeClass('active');
        $(this).addClass('active');
        $('.tab-content').hide();
        $('#' + $(this).data('tab')).show();
        if ($(this).data('tab') === 'logs') {
            loadLogs();
        }
    });

    // دکمه خروج
    $('#logout-btn').click(function() {
        window.location.href = '<?php echo wp_logout_url(home_url('/cashier')); ?>';
    });

    // چک کردن سفارش جدید
    function checkNewOrders() {
        $.ajax({
            url: darkhoone_vars.ajax_url,
            method: 'POST',
            data: {
                action: 'check_new_orders',
                nonce: darkhoone_vars.nonce
            },
            success: function(response) {
                if (response.success && response.data.new_order) {
                    $('#order-notification').fadeIn();
                    setTimeout(function() {
                        $('#order-notification').fadeOut();
                    }, 5000);
                }
            }
        });
    }
    setInterval(checkNewOrders, 10000);

    // فرم محصول
    $('#product-form').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: darkhoone_vars.ajax_url,
            method: 'POST',
            data: {
                action: 'save_product',
                nonce: darkhoone_vars.nonce,
                product_id: $('#product-id').val(),
                product_name: $('#product-name').val(),
                product_price: $('#product-price').val()
            },
            success: function(response) {
                if (response.success) {
                    alert('محصول ذخیره شد!');
                    location.reload(); // رفرش برای آپدیت لیست
                } else {
                    alert('خطا: ' + response.data.message);
                }
            }
        });
    });

    $('.edit-product').click(function() {
        $('#product-id').val($(this).data('id'));
        $('#product-name').val($(this).data('name'));
        $('#product-price').val($(this).data('price'));
    });

    // لود لاگ‌ها
    function loadLogs() {
        $.ajax({
            url: darkhoone_vars.ajax_url,
            method: 'POST',
            data: {
                action: 'get_app_logs',
                nonce: darkhoone_vars.nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#log-list').html('<ul>' + response.data.logs.map(log => '<li>' + log + '</li>').join('') + '</ul>');
                } else {
                    $('#log-list').html('<p>خطا در بارگذاری لاگ‌ها</p>');
                }
            }
        });
    }

    // ارسال نوتیفیکیشن
    $('#notification-form').submit(function(e) {
        e.preventDefault();
        $.ajax({
            url: darkhoone_vars.ajax_url,
            method: 'POST',
            data: {
                action: 'send_notification',
                nonce: darkhoone_vars.nonce,
                message: $('#notification-message').val()
            },
            success: function(response) {
                if (response.success) {
                    alert('نوتیفیکیشن ارسال شد!');
                    $('#notification-message').val('');
                } else {
                    alert('خطا: ' + response.data.message);
                }
            }
        });
    });
});