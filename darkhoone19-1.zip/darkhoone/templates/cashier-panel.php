<?php
// templates/cashier-panel.php
if (!defined('ABSPATH')) {
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>پنل صندوق‌دار درخونه</title>
    <style>
        body { font-family: 'Vazir', sans-serif; margin: 0; padding: 0; background: #f4f4f4; }
        #cashier-panel { display: flex; max-width: 1200px; margin: 20px auto; }
        .sidebar { width: 250px; background: #fff; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); border-radius: 8px; }
        .sidebar ul { list-style: none; padding: 0; margin: 0; }
        .sidebar li { margin-bottom: 10px; }
        .sidebar a { text-decoration: none; color: #0073aa; font-weight: bold; display: block; padding: 10px; border-radius: 5px; }
        .sidebar a:hover, .sidebar a.active { background: #0073aa; color: #fff; }
        .main-content { flex-grow: 1; margin-right: 20px; }
        header { display: flex; justify-content: space-between; align-items: center; background: #0073aa; color: #fff; padding: 15px 20px; border-radius: 8px 8px 0 0; }
        header h1 { margin: 0; font-size: 24px; }
        #logout-btn { background: #d9534f; color: #fff; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer; }
        #logout-btn:hover { background: #c9302c; }
        .section-content { background: #fff; padding: 20px; border-radius: 0 0 8px 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); display: none; }
        .section-content.active { display: block; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { padding: 12px; text-align: right; border-bottom: 1px solid #ddd; }
        th { background: #f8f8f8; font-weight: bold; }
        .order-details-link { cursor: pointer; color: #0073aa; text-decoration: underline; }
        .order-details-link:hover { color: #005d87; }
        .order-status-select { padding: 5px; border-radius: 5px; border: 1px solid #ddd; }
        #product-form, #notification-form, #settings-form, #order-hours-form, #sms-discounts-form { display: flex; flex-direction: column; gap: 10px; max-width: 400px; margin-bottom: 20px; }
        #product-form label, #notification-form label, #settings-form label, #order-hours-form label, #sms-discounts-form label { font-weight: bold; }
        #product-form input, #notification-form textarea, #settings-form input, #order-hours-form input, #sms-discounts-form input, #sms-discounts-form textarea, #product-form select { padding: 8px; border-radius: 5px; border: 1px solid #ddd; }
        #product-form button, #notification-form button, #settings-form button, #order-hours-form button, #sms-discounts-form button { background: #28a745; color: #fff; border: none; padding: 10px; border-radius: 5px; cursor: pointer; }
        #product-form button:hover, #notification-form button:hover, #settings-form button:hover, #order-hours-form button:hover, #sms-discounts-form button:hover { background: #218838; }
        .edit-product { background: #0073aa; color: #fff; border: none; padding: 5px 10px; border-radius: 3px; cursor: pointer; }
        .edit-product:hover { background: #005d87; }
        #order-notification { 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            background: #28a745; 
            color: #fff; 
            padding: 40px 80px; 
            border-radius: 15px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.3); 
            display: none; 
            font-size: 32px; 
            z-index: 1000; 
        }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: #fff; margin: 50px auto; padding: 20px; max-width: 600px; border-radius: 8px; position: relative; }
        .close-modal { position: absolute; top: 10px; left: 10px; font-size: 24px; cursor: pointer; }
        #product-image-preview { max-width: 100px; margin-top: 10px; }
        @media print {
            body { 
                font-family: 'Vazir', sans-serif; 
                margin: 2mm; 
                padding: 0; 
                font-size: 10px; 
                width: 80mm; 
                box-sizing: border-box; 
            }
            table { 
                width: 100%; 
                border-collapse: collapse; 
                margin-top: 2mm; 
            }
            th, td { 
                padding: 2px; 
                border: 1px solid #000; 
                text-align: right; 
                font-size: 9px; 
                word-wrap: break-word; 
                max-width: 25mm; 
                overflow: hidden; 
                text-overflow: ellipsis; 
            }
            th { 
                background: #f0f0f0; 
                font-weight: bold; 
            }
            h2 { 
                font-size: 12px; 
                margin: 0 0 2mm; 
                text-align: center; 
            }
            .no-print { 
                display: none; 
            }
        }
    </style>
</head>
<body>
    <!-- صدا برای نوتیفیکیشن -->
    <audio id="notification-sound" src="<?php echo plugins_url('darkhoone/assets/beep.mp3'); ?>" preload="auto"></audio>

    <div id="cashier-panel">
        <!-- منوی عمودی -->
        <div class="sidebar">
            <ul>
                <li><a href="#" class="menu-link active" data-section="about">درباره درخونه</a></li>
                <li><a href="#" class="menu-link" data-section="settings">تنظیمات عمومی</a></li>
                <?php if (darkhoone_is_module_active('order_hours')): ?>
                    <li><a href="#" class="menu-link" data-section="order-hours">ساعت‌های سفارش</a></li>
                <?php endif; ?>
                <?php if (darkhoone_is_module_active('sms_discounts')): ?>
                    <li><a href="#" class="menu-link" data-section="sms-discounts">پیامک تخفیف</a></li>
                <?php endif; ?>
                <li><a href="#" class="menu-link" data-section="orders">سفارشات</a></li>
                <li><a href="#" class="menu-link" data-section="products">محصولات</a></li>
                <li><a href="#" class="menu-link" data-section="sms-logs">آرشیو پیامک</a></li>
                <li><a href="#" class="menu-link" data-section="logs">لاگ‌ها</a></li>
                <li><a href="#" class="menu-link" data-section="notifications">ارسال نوتیفیکیشن</a></li>
            </ul>
        </div>

        <!-- محتوای اصلی -->
        <div class="main-content">
            <header>
                <h1>❤️ پنل صندوق‌دار درخونه</h1>
                <button id="logout-btn">خروج</button>
            </header>

            <!-- بخش‌های منو -->
            <div class="section-content active" id="about">
                <div style="max-width: 600px; margin: 20px auto; padding: 30px; background: #fff; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
                    <h2 style="font-size: 28px; color: #333; margin-bottom: 20px;">خوش آمدید به درخونه</h2>
                    <p style="font-size: 16px; color: #666; line-height: 1.6; margin-bottom: 20px;">
                        طراحی و توسعه با ❤️ توسط <strong>داده‌پردازی مهرگان و شکرانه</strong>
                    </p>
                    <p style="font-size: 14px; color: #888; margin-bottom: 0;">
                        ما اینجاییم: تیران، جنب بیمارستان بهنیا، تلفن: ۰۳۱۹۱۰۹۰۱۲۳
                    </p>
                </div>
            </div>

            <div class="section-content" id="settings">
                <h2>تنظیمات عمومی</h2>
                <form id="settings-form" method="post">
                    <?php
                    $modules = [
                        'delivery_options' => 'گزینه‌های تحویل',
                        'order_hours' => 'ساعت‌های سفارش',
                        'sms_discounts' => 'پیامک تخفیف',
                        'new_order_notification' => 'اعلان سفارش جدید',
                        'simple_dashboard' => 'پیشخوان ساده'
                    ];
                    $options = get_option('darkhoone_modules', []);
                    foreach ($modules as $key => $label) {
                        $checked = isset($options[$key]) && $options[$key] == 1 ? 'checked' : '';
                        echo "<label><input type='checkbox' name='darkhoone_modules[$key]' value='1' $checked> $label</label><br>";
                    }
                    ?>
                    <button type="submit">ذخیره</button>
                </form>
            </div>

            <?php if (darkhoone_is_module_active('order_hours')): ?>
            <div class="section-content" id="order-hours">
                <h2>ساعت‌های سفارش</h2>
                <form id="order-hours-form" method="post">
                    <label><input type="checkbox" name="enabled" value="1"> فعال کردن محدودیت</label><br>
                    <label>شروع بازه صبح: <input type="time" name="morning_start"></label><br>
                    <label>پایان بازه صبح: <input type="time" name="morning_end"></label><br>
                    <label>شروع بازه عصر: <input type="time" name="evening_start"></label><br>
                    <label>پایان بازه عصر: <input type="time" name="evening_end"></label><br>
                    <label>پیام سبد خرید: <textarea name="cart_message"></textarea></label><br>
                    <label>پیام تسویه حساب: <textarea name="checkout_message"></textarea></label><br>
                    <label>پیام صفحه اصلی: <textarea name="front_message"></textarea></label><br>
                    <button type="submit">ذخیره</button>
                </form>
            </div>
            <?php endif; ?>

            <?php if (darkhoone_is_module_active('sms_discounts')): ?>
            <div class="section-content" id="sms-discounts">
                <h2>پیامک تخفیف</h2>
                <form id="sms-discounts-form" method="post">
                    <label>درصد تخفیف: <input type="number" name="discount_percentage" min="1" max="100"></label><br>
                    <label>مدت اعتبار (روز): <input type="number" name="expiry_days" min="1"></label><br>
                    <label>متن پیامک: <textarea name="sms_message"></textarea></label><br>
                    <p>متغیرها: {coupon_code}, {percentage}, {expiry_days}</p>
                    <button type="submit">ذخیره</button>
                </form>
            </div>
            <?php endif; ?>

            <div class="section-content" id="orders">
                <h2>سفارشات در حال پردازش</h2>
                <div id="orders-table">
                    <?php
                    $args = array(
                        'limit' => 20,
                        'orderby' => 'date',
                        'order' => 'DESC',
                        'status' => array_diff(array_keys(wc_get_order_statuses()), array('wc-completed')),
                    );
                    $orders = wc_get_orders($args);
                    if ($orders) {
                        echo '<table>';
                        echo '<tr><th>شماره سفارش</th><th>تاریخ</th><th>مشتری</th><th>روش تحویل</th><th>جمع کل</th><th>وضعیت</th><th>عملیات</th></tr>';
                        foreach ($orders as $order) {
                            $order_id = $order->get_id();
                            $status = $order->get_status();
                            $status_name = wc_get_order_status_name($status);
                            $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                            $delivery_option = get_post_meta($order_id, '_delivery_option', true);
                            $delivery_method = $delivery_option === 'pickup' ? 'تحویل حضوری' : ($delivery_option === 'courier' ? 'ارسال با پیک' : 'نامشخص');
                            $total = $order->get_total();
                            $date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp()) : wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');
                            echo '<tr data-order_id="' . $order_id . '">';
                            echo '<td><a href="#" class="order-details-link" data-order_id="' . $order_id . '">#' . $order_id . '</a></td>';
                            echo '<td>' . esc_html($date) . '</td>';
                            echo '<td>' . ($customer_name ?: 'مهمان') . '</td>';
                            echo '<td>' . esc_html($delivery_method) . '</td>';
                            echo '<td>' . wc_price($total) . '</td>';
                            echo '<td class="order-status">' . $status_name . '</td>';
                            echo '<td>';
                            echo '<select class="order-status-select" data-order_id="' . $order_id . '">';
                            $statuses = wc_get_order_statuses();
                            foreach ($statuses as $status_key => $status_name_option) {
                                $selected = ($status_key === 'wc-' . $status ? 'selected' : '');
                                echo '<option value="' . esc_attr($status_key) . '" ' . $selected . '>' . esc_html($status_name_option) . '</option>';
                            }
                            echo '</select>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p>سفارشی در حال پردازش نیست.</p>';
                    }
                    ?>
                </div>
            </div>

            <div class="section-content" id="products">
                <h2>محصولات</h2>
                <form id="product-form" method="post" enctype="multipart/form-data">
                    <label for="product-name">نام محصول:</label>
                    <input type="text" id="product-name" name="product_name" required>
                    <label for="product-price">قیمت اصلی (تومان):</label>
                    <input type="number" id="product-price" name="product_price" min="0" step="1" required>
                    <label for="product-sale-price">قیمت فروش ویژه (تومان):</label>
                    <input type="number" id="product-sale-price" name="product_sale_price" min="0" step="1">
                    <label for="product-stock">تعداد موجودی:</label>
                    <input type="number" id="product-stock" name="product_stock" min="0" step="1">
                    <label for="product-category">دسته‌بندی:</label>
                    <select id="product-category" name="product_category">
                        <option value="">انتخاب دسته‌بندی</option>
                        <?php
                        $categories = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
                        foreach ($categories as $category) {
                            echo '<option value="' . esc_attr($category->term_id) . '">' . esc_html($category->name) . '</option>';
                        }
                        ?>
                    </select>
                    <label for="product-image">تصویر محصول:</label>
                    <input type="file" id="product-image" name="product_image" accept="image/*">
                    <img id="product-image-preview" src="" alt="" style="display: none;">
                    <input type="hidden" id="product-id" name="product_id">
                    <button type="submit">ذخیره</button>
                </form>
                <div id="product-list">
                    <?php
                    $products = wc_get_products(array('limit' => 10));
                    if ($products) {
                        echo '<table>';
                        echo '<tr><th>تصویر</th><th>نام</th><th>قیمت اصلی</th><th>قیمت تخفیف</th><th>موجودی</th><th>دسته‌بندی</th><th>عملیات</th></tr>';
                        foreach ($products as $product) {
                            $image = $product->get_image('thumbnail');
                            $regular_price = wc_price($product->get_regular_price());
                            $sale_price = $product->get_sale_price() ? wc_price($product->get_sale_price()) : '-';
                            $stock = $product->get_stock_quantity() !== null ? $product->get_stock_quantity() : 'نامحدود';
                            $category_ids = $product->get_category_ids();
                            $category = !empty($category_ids) ? get_term($category_ids[0])->name : '-';
                            echo '<tr>';
                            echo '<td>' . $image . '</td>';
                            echo '<td>' . esc_html($product->get_name()) . '</td>';
                            echo '<td>' . $regular_price . '</td>';
                            echo '<td>' . $sale_price . '</td>';
                            echo '<td>' . $stock . '</td>';
                            echo '<td>' . esc_html($category) . '</td>';
                            echo '<td><button class="edit-product" data-id="' . $product->get_id() . '" data-name="' . esc_attr($product->get_name()) . '" data-price="' . $product->get_regular_price() . '" data-sale-price="' . $product->get_sale_price() . '" data-stock="' . $product->get_stock_quantity() . '" data-category="' . esc_attr($category_ids[0] ?? '') . '" data-image="' . esc_attr(wp_get_attachment_url($product->get_image_id())) . '">ویرایش</button></td>';
                            echo '</tr>';
                        }
                        echo '</table>';
                    } else {
                        echo '<p>محصولی یافت نشد.</p>';
                    }
                    ?>
                </div>
            </div>

            <div class="section-content" id="sms-logs">
                <h2>آرشیو پیامک</h2>
                <div id="sms-log-list">
                    <p>در حال بارگذاری...</p>
                </div>
            </div>

            <div class="section-content" id="logs">
                <h2>لاگ‌ها</h2>
                <div id="log-list">
                    <p>در حال بارگذاری...</p>
                </div>
            </div>

            <div class="section-content" id="notifications">
                <h2>ارسال نوتیفیکیشن</h2>
                <form id="notification-form">
                    <label for="notification-message">پیام:</label>
                    <textarea id="notification-message" name="message" rows="3" required></textarea>
                    <button type="submit">ارسال</button>
                </form>
            </div>

            <!-- اعلان سفارش جدید و مودال -->
            <div id="order-notification">
                <p>سفارش جدید ثبت شد!</p>
            </div>
            <div id="order-modal" class="modal">
                <div class="modal-content">
                    <span class="close-modal">×</span>
                    <div id="order-details-content"></div>
                    <button id="print-order-btn" class="no-print">چاپ فیش</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        jQuery(document).ready(function($) {
            var restUrl = '<?php echo esc_url(rest_url('darkhoone/v1')); ?>';
            var nonce = '<?php echo wp_create_nonce('wp_rest'); ?>';
            var ajaxUrl = '<?php echo admin_url('admin-ajax.php'); ?>';
            var notificationSound = document.getElementById('notification-sound');

            // مدیریت منوها
            $('.menu-link').on('click', function(e) {
                e.preventDefault();
                $('.menu-link').removeClass('active');
                $(this).addClass('active');
                $('.section-content').removeClass('active');
                var section = $(this).data('section');
                $('#' + section).addClass('active');
                if (section === 'logs') loadLogs();
                if (section === 'sms-logs') loadSmsLogs();
                if (section === 'order-hours') loadOrderHours();
                if (section === 'sms-discounts') loadSmsDiscounts();
            });

            // دکمه خروج
            $('#logout-btn').on('click', function() {
                window.location.href = '<?php echo wp_logout_url(home_url('/cashier')); ?>';
            });

            // ذخیره تنظیمات عمومی
            $('#settings-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'save_settings',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>',
                        darkhoone_modules: $(this).serializeArray().reduce(function(obj, item) {
                            if (item.name.startsWith('darkhoone_modules')) {
                                var key = item.name.match(/\[(.+)\]/)[1];
                                obj[key] = item.value;
                            }
                            return obj;
                        }, {})
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('تنظیمات ذخیره شد!');
                            location.reload();
                        } else {
                            alert('خطا: ' + response.data.message);
                        }
                    }
                });
            });

            // بارگذاری ساعت‌های سفارش
            function loadOrderHours() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'load_order_hours',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            var data = response.data;
                            $('#order-hours-form [name="enabled"]').prop('checked', data.enabled == 1);
                            $('#order-hours-form [name="morning_start"]').val(data.morning_start);
                            $('#order-hours-form [name="morning_end"]').val(data.morning_end);
                            $('#order-hours-form [name="evening_start"]').val(data.evening_start);
                            $('#order-hours-form [name="evening_end"]').val(data.evening_end);
                            $('#order-hours-form [name="cart_message"]').val(data.cart_message);
                            $('#order-hours-form [name="checkout_message"]').val(data.checkout_message);
                            $('#order-hours-form [name="front_message"]').val(data.front_message);
                        }
                    }
                });
            }

            // ذخیره ساعت‌های سفارش
            $('#order-hours-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'save_order_hours',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>',
                        enabled: $(this).find('[name="enabled"]').is(':checked') ? 1 : 0,
                        morning_start: $(this).find('[name="morning_start"]').val(),
                        morning_end: $(this).find('[name="morning_end"]').val(),
                        evening_start: $(this).find('[name="evening_start"]').val(),
                        evening_end: $(this).find('[name="evening_end"]').val(),
                        cart_message: $(this).find('[name="cart_message"]').val(),
                        checkout_message: $(this).find('[name="checkout_message"]').val(),
                        front_message: $(this).find('[name="front_message"]').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('تنظیمات ذخیره شد!');
                            loadOrderHours();
                        } else {
                            alert('خطا: ' + response.data.message);
                        }
                    }
                });
            });

            // بارگذاری پیامک تخفیف
            function loadSmsDiscounts() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'load_sms_discounts',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            var data = response.data;
                            $('#sms-discounts-form [name="discount_percentage"]').val(data.discount_percentage);
                            $('#sms-discounts-form [name="expiry_days"]').val(data.expiry_days);
                            $('#sms-discounts-form [name="sms_message"]').val(data.sms_message);
                        }
                    }
                });
            }

            // ذخیره پیامک تخفیف
            $('#sms-discounts-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'save_sms_discounts',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>',
                        discount_percentage: $(this).find('[name="discount_percentage"]').val(),
                        expiry_days: $(this).find('[name="expiry_days"]').val(),
                        sms_message: $(this).find('[name="sms_message"]').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('تنظیمات ذخیره شد!');
                            loadSmsDiscounts();
                        } else {
                            alert('خطا: ' + response.data.message);
                        }
                    }
                });
            });

            // اعلان سفارش جدید
            function showNotification(orderId, message = '') {
                $('#order-notification').text(message || 'سفارش جدید با شماره ' + orderId + ' ثبت شد!').fadeIn();
                notificationSound.play().catch(function(error) {
                    console.log('خطا در پخش صدا: ', error);
                });
                setTimeout(function() {
                    $('#order-notification').fadeOut();
                }, 5000);
            }

            function updateOrdersTable() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'get_pending_orders',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.html) {
                            $('#orders-table').html(response.data.html);
                        }
                    }
                });
            }

            function checkNewOrders() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'check_new_orders',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data.new_order) {
                            showNotification(response.data.order_id || '');
                            updateOrdersTable();
                        }
                    }
                });
            }
            setInterval(checkNewOrders, 10000);

            // مدیریت محصولات
            $('#product-form').on('submit', function(e) {
                e.preventDefault();
                var formData = new FormData(this);
                formData.append('action', 'save_product');
                formData.append('nonce', '<?php echo wp_create_nonce('darkhoone_nonce'); ?>');
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: formData,
                    processData: false,
                    contentType: false,
                    success: function(response) {
                        if (response.success) {
                            alert('محصول ذخیره شد!');
                            location.reload();
                        } else {
                            alert('خطا: ' + response.data.message);
                        }
                    }
                });
            });

            $('.edit-product').on('click', function() {
                $('#product-id').val($(this).data('id'));
                $('#product-name').val($(this).data('name'));
                $('#product-price').val($(this).data('price'));
                $('#product-sale-price').val($(this).data('sale-price') || '');
                $('#product-stock').val($(this).data('stock') || '');
                $('#product-category').val($(this).data('category') || '');
                var imageUrl = $(this).data('image');
                if (imageUrl) {
                    $('#product-image-preview').attr('src', imageUrl).show();
                } else {
                    $('#product-image-preview').hide();
                }
            });

            $('#product-image').on('change', function(e) {
                var file = e.target.files[0];
                if (file) {
                    $('#product-image-preview').attr('src', URL.createObjectURL(file)).show();
                }
            });

            // بارگذاری آرشیو پیامک
            function loadSmsLogs() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'get_sms_logs',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            var logs = response.data.logs;
                            var html = '<table><tr><th>تاریخ و ساعت</th><th>شماره سفارش</th><th>شماره گیرنده</th><th>متن پیامک</th><th>وضعیت</th></tr>';
                            logs.forEach(function(log) {
                                html += '<tr>';
                                html += '<td>' + log.date + '</td>';
                                html += '<td>' + log.order_id + '</td>';
                                html += '<td>' + log.reciever + '</td>';
                                html += '<td>' + log.message + '</td>';
                                html += '<td>' + log.status + '</td>';
                                html += '</tr>';
                            });
                            html += '</table>';
                            $('#sms-log-list').html(html);
                        } else {
                            $('#sms-log-list').html('<p>' + response.data.message + '</p>');
                        }
                    }
                });
            }

            // بارگذاری لاگ‌ها
            function loadLogs() {
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'get_app_logs',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            var logs = response.data.logs;
                            var html = '<table><tr><th>IMEI کاربر</th><th>مدل دستگاه</th><th>نسخه اپلیکیشن</th><th>موقعیت</th><th>تاریخ نصب</th><th>آخرین آنلاین</th></tr>';
                            logs.forEach(function(log) {
                                html += '<tr>';
                                html += '<td>' + log.user_imei + '</td>';
                                html += '<td>' + log.device_model + '</td>';
                                html += '<td>' + log.app_version + '</td>';
                                html += '<td>' + log.location + '</td>';
                                html += '<td>' + log.install_date + '</td>';
                                html += '<td>' + log.online_date + '</td>';
                                html += '</tr>';
                            });
                            html += '</table>';
                            $('#log-list').html(html);
                        } else {
                            $('#log-list').html('<p>' + response.data.message + '</p>');
                        }
                    }
                });
            }

            // ارسال نوتیفیکیشن
            $('#notification-form').on('submit', function(e) {
                e.preventDefault();
                $.ajax({
                    url: ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'send_notification',
                        nonce: '<?php echo wp_create_nonce('darkhoone_nonce'); ?>',
                        message: $('#notification-message').val()
                    },
                    success: function(response) {
                        if (response.success) {
                            alert(response.data.message);
                            $('#notification-message').val('');
                        } else {
                            alert('خطا: ' + response.data.message);
                        }
                    }
                });
            });

            // نمایش جزئیات سفارش
            $(document).on('click', '.order-details-link', function(e) {
                e.preventDefault();
                var orderId = $(this).data('order_id');
                $.ajax({
                    url: restUrl + '/order_details/' + orderId,
                    method: 'POST',
                    dataType: 'json',
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', nonce);
                    },
                    success: function(response) {
                        if (response && response.content) {
                            $('#order-details-content').html(response.content);
                            $('#order-modal').css('display', 'block');
                        } else {
                            alert('خطا در بارگذاری جزئیات سفارش');
                        }
                    }
                });
            });

            // بستن مودال
            $(document).on('click', '.close-modal', function() {
                $('#order-modal').css('display', 'none');
            });

            // چاپ فیش
            $(document).on('click', '#print-order-btn', function() {
                var printContents = $('#order-details-content').html();
                var originalContents = $('body').html();
                $('body').html(printContents);
                window.print();
                $('body').html(originalContents);
            });

            // تغییر وضعیت سفارش
            $(document).on('change', '.order-status-select', function() {
                var $select = $(this);
                var orderId = $select.data('order_id');
                var newStatus = $select.val();
                var $statusCell = $select.closest('tr').find('.order-status');
                $.ajax({
                    url: restUrl + '/update_order_status',
                    method: 'POST',
                    data: JSON.stringify({
                        order_id: orderId,
                        status: newStatus
                    }),
                    contentType: 'application/json',
                    beforeSend: function(xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', nonce);
                    },
                    success: function(response) {
                        if (response && response.message) {
                            $statusCell.text(response.status_name);
                            alert(response.message);
                        }
                    },
                    error: function(xhr) {
                        alert('خطا در به‌روزرسانی وضعیت');
                    }
                });
            });
        });
    </script>
</body>
</html>