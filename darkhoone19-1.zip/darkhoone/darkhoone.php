<?php
/*
Plugin Name: Darkhoone
Description: پکیج کامل ابزارهای درخونه برای ووکامرس با تنظیمات ماژولار
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit;
}

// لود فایل‌های ماژولار
require_once plugin_dir_path(__FILE__) . 'includes/delivery-options.php';
require_once plugin_dir_path(__FILE__) . 'includes/order-hours.php';
require_once plugin_dir_path(__FILE__) . 'includes/sms-discounts.php';
require_once plugin_dir_path(__FILE__) . 'includes/new-order-notification.php';
require_once plugin_dir_path(__FILE__) . 'includes/simple-dashboard.php';

// فعال‌سازی دیباگ
if (!defined('WP_DEBUG')) {
    define('WP_DEBUG', true);
    define('WP_DEBUG_LOG', true);
    define('WP_DEBUG_DISPLAY', false);
}

// ساخت و اصلاح نقش
add_action('init', 'darkhoone_create_new_role', 1);
function darkhoone_create_new_role() {
    error_log('Creating/Updating darkhoone_manager role - ' . date('Y-m-d H:i:s'));

    remove_role('darkhoone_manager');

    $capabilities = array(
        'read' => true,
        'manage_woocommerce' => true,
        'view_admin_dashboard' => true,
        'edit_products' => true,
        'publish_products' => true,
        'edit_published_products' => true,
        'edit_others_products' => true,
        'delete_products' => true,
        'delete_published_products' => true,
        'manage_product_terms' => true,
        'edit_product_terms' => true,
        'delete_product_terms' => true,
        'assign_product_terms' => true,
        'read_private_products' => true,
        'edit_shop_orders' => true,
        'publish_shop_orders' => true,
        'read_shop_order' => true,
        'edit_others_shop_orders' => true,
        'delete_shop_orders' => true,
        'delete_others_shop_orders' => true,
        'read_private_shop_orders' => true,
        'manage_darkhoone' => true,
        'manage_options' => true,
    );

    add_role('darkhoone_manager', 'مدیر درخونه', $capabilities);

    $role = get_role('darkhoone_manager');
    foreach ($capabilities as $cap => $value) {
        if (!$role->has_cap($cap)) {
            $role->add_cap($cap);
        }
    }

    $admin_role = get_role('administrator');
    if ($admin_role) {
        $admin_role->add_cap('manage_darkhoone');
        $admin_role->add_cap('manage_woocommerce');
    }
}

// منوی اصلی و زیرمنوها
add_action('admin_menu', 'darkhoone_register_main_menu', 9);
function darkhoone_register_main_menu() {
    add_menu_page(
        'درخونه',
        'درخونه',
        'manage_darkhoone',
        'darkhoone_menu',
        'darkhoone_menu_page',
        'dashicons-store',
        3
    );

    add_submenu_page(
        'darkhoone_menu',
        'درباره درخونه',
        'درباره درخونه',
        'manage_darkhoone',
        'darkhoone_menu',
        'darkhoone_menu_page'
    );

    add_submenu_page(
        'darkhoone_menu',
        'تنظیمات عمومی',
        'تنظیمات عمومی',
        'manage_darkhoone',
        'darkhoone_settings',
        'darkhoone_settings_page'
    );

    if (darkhoone_is_module_active('order_hours')) {
        add_submenu_page(
            'darkhoone_menu',
            'ساعت‌های سفارش',
            'ساعت‌های سفارش',
            'manage_darkhoone',
            'darkhoone_order_hours',
            'darkhoone_oh_order_hours_settings_page'
        );
    }

    if (darkhoone_is_module_active('sms_discounts')) {
        add_submenu_page(
            'darkhoone_menu',
            'پیامک تخفیف',
            'پیامک تخفیف',
            'manage_darkhoone',
            'darkhoone_sms_discounts',
            'darkhoone_sd_settings_page'
        );
    }

    if (darkhoone_is_module_active('simple_dashboard')) {
        add_submenu_page(
            'darkhoone_menu',
            'پیشخوان ساده',
            'پیشخوان ساده',
            'manage_woocommerce',
            'darkhoone_simple_dashboard',
            'darkhoone_sd_render_simple_dashboard'
        );
    }
}

// صفحه خوش‌آمدگویی
function darkhoone_menu_page() {
    ?>
    <div class="wrap">
        <div style="max-width: 600px; margin: 40px auto; padding: 30px; background: #fff; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); text-align: center;">
            <h1 style="font-size: 28px; color: #333; margin-bottom: 20px;">خوش آمدید به درخونه</h1>
            <p style="font-size: 16px; color: #666; line-height: 1.6; margin-bottom: 20px;">
                طراحی و توسعه با ❤️ توسط <strong>داده‌پردازی مهرگان و شکرانه</strong>
            </p>
            <p style="font-size: 14px; color: #888; margin-bottom: 0;">
                ما اینجاییم: تیران، جنب بیمارستان بهنیا، تلفن: ۰۳۱۹۱۰۹۰۱۲۳
            </p>
        </div>
    </div>
    <?php
}

// صفحه تنظیمات عمومی
function darkhoone_settings_page() {
    ?>
    <div class="wrap">
        <h1>تنظیمات عمومی درخونه</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('darkhoone_settings_group');
            do_settings_sections('darkhoone_settings');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

// ثبت تنظیمات
add_action('admin_init', 'darkhoone_register_settings');
function darkhoone_register_settings() {
    register_setting('darkhoone_settings_group', 'darkhoone_modules');

    add_settings_section(
        'darkhoone_modules_section',
        'فعال‌سازی ماژول‌ها',
        function() { echo '<p>ماژول‌های مورد نظر خود را فعال یا غیرفعال کنید</p>'; },
        'darkhoone_settings'
    );

    $modules = [
        'delivery_options' => 'گزینه‌های تحویل',
        'order_hours' => 'ساعت‌های سفارش',
        'sms_discounts' => 'پیامک تخفیف',
        'new_order_notification' => 'اعلان سفارش جدید',
        'simple_dashboard' => 'پیشخوان ساده'
    ];

    foreach ($modules as $key => $label) {
        add_settings_field(
            "darkhoone_module_$key",
            $label,
            function() use ($key) {
                $options = get_option('darkhoone_modules', []);
                $checked = isset($options[$key]) && $options[$key] == 1 ? 1 : 0;
                echo "<input type='checkbox' name='darkhoone_modules[$key]' value='1' " . checked(1, $checked, false) . " />";
            },
            'darkhoone_settings',
            'darkhoone_modules_section'
        );
    }
}

// بررسی فعال بودن ماژول
function darkhoone_is_module_active($module) {
    $options = get_option('darkhoone_modules', []);
    return isset($options[$module]) && $options[$module] == 1;
}

// حذف همه منوهای اضافی
add_action('admin_menu', 'darkhoone_remove_all_menus', 999);
function darkhoone_remove_all_menus() {
    $user = wp_get_current_user();
    if (in_array('darkhoone_manager', $user->roles) && !in_array('administrator', $user->roles)) {
        global $menu, $submenu;

        $allowed_menus = [
            'darkhoone_menu',
            'edit.php?post_type=product',
            'edit.php?post_type=shop_order',
            'index.php',
            'admin.php?page=appsite_send_notif',
            'admin.php?page=persian-woocommerce-sms-pro&tab=archive',
            'admin.php?page=appsite_app_logs'
        ];

        foreach ($menu as $key => $value) {
            $menu_slug = $value[2] ?? '';
            if (!in_array($menu_slug, $allowed_menus)) {
                remove_menu_page($menu_slug);
            }
        }

        $forced_removals = [
            'abzarwp-easy-installer-license',
            'users.php',
            'edit.php',
            'edit.php?post_type=page',
            'elementor',
            'themes.php',
            'crocoblock',
            'digits',
            'tools.php',
            'zhaket-updater',
            'appset',
            'duplicator',
            'wp-tools-license'
        ];
        
        foreach ($forced_removals as $slug) {
            remove_menu_page($slug);
        }

        if(isset($submenu['abzarwp-easy-installer-license'])) {
            unset($submenu['abzarwp-easy-installer-license']);
        }
    }
}

// افزودن منوهای سفارشی
add_action('admin_menu', 'darkhoone_add_custom_menus', 1000);
function darkhoone_add_custom_menus() {
    $user = wp_get_current_user();
    if (in_array('darkhoone_manager', $user->roles) && !in_array('administrator', $user->roles)) {
        remove_menu_page('edit.php?post_type=product');
        remove_menu_page('edit.php?post_type=shop_order');

        add_menu_page(
            'محصولات',
            'محصولات',
            'edit_products',
            'edit.php?post_type=product',
            '',
            'dashicons-products',
            4
        );

        add_menu_page(
            'سفارشات',
            'سفارشات',
            'edit_shop_orders',
            'edit.php?post_type=shop_order',
            '',
            'dashicons-cart',
            5
        );

        add_menu_page(
            'لاگ‌های اپلیکیشن',
            'لاگ‌های اپلیکیشن',
            'manage_darkhoone',
            'admin.php?page=appsite_app_logs',
            '',
            'dashicons-list-view',
            6
        );

        add_menu_page(
            'آرشیو پیامک',
            'آرشیو پیامک',
            'manage_woocommerce',
            'admin.php?page=persian-woocommerce-sms-pro&tab=archive',
            '',
            'dashicons-email',
            7
        );

        add_menu_page(
            'ارسال نوتیفیکیشن',
            'ارسال نوتیفیکیشن',
            'manage_darkhoone',
            'admin.php?page=appsite_send_notif',
            '',
            'dashicons-bell',
            8
        );
    }
}

// ویجت پیشخوان
add_action('wp_dashboard_setup', 'darkhoone_add_dashboard_widgets');
function darkhoone_add_dashboard_widgets() {
    wp_add_dashboard_widget(
        'darkhoone_widget',
        'درخونه',
        'darkhoone_widget_callback'
    );
}

function darkhoone_widget_callback() {
    ?>
    <div class="darkhoone-widget">
        <div class="darkhoone-about">
            <h3 style="margin-top: 0; color: #0073aa;">درخونه</h3>
            <p style="line-height: 1.6;">طراحی و توسعه با ❤️ توسط <strong>داده‌پردازی مهرگان و شکرانه</strong></p>
            <p style="font-size: 12px;">ما اینجاییم: تیران، جنب بیمارستان بهنیا، تلفن: ۰۳۱۹۱۰۹۰۱۲۳</p>
        </div>
        <div class="darkhoone-tools">
            <h4 style="color: #0073aa; margin: 15px 0 10px;">ابزارهای فعال</h4>
            <?php if (darkhoone_is_module_active('order_hours')): ?>
                <div class="darkhoone-tool-item">
                    <p><strong>ساعت‌های سفارش</strong></p>
                    <?php $options = get_option('darkhoone_order_hours_options'); ?>
                    <p><?php echo $options['enabled'] ? 'فعال' : 'غیرفعال'; ?></p>
                    <?php if ($options['enabled']): ?>
                        <p><?php echo $options['morning_start'] . ' تا ' . $options['morning_end']; ?></p>
                        <p><?php echo $options['evening_start'] . ' تا ' . $options['evening_end']; ?></p>
                    <?php endif; ?>
                    <p><a href="<?php echo admin_url('admin.php?page=darkhoone_order_hours'); ?>" class="button">تنظیمات</a></p>
                </div>
            <?php endif; ?>
            
            <?php if (darkhoone_is_module_active('sms_discounts')): ?>
                <div class="darkhoone-tool-item">
                    <p><strong>پیامک تخفیف</strong></p>
                    <?php
                    $discount = get_option('darkhoone_sd_discount_percentage', 10);
                    $expiry_days = get_option('darkhoone_sd_expiry_days', 7);
                    ?>
                    <p>تخفیف: <?php echo $discount; ?>%</p>
                    <p>اعتبار: <?php echo $expiry_days; ?> روز</p>
                    <p><a href="<?php echo admin_url('admin.php?page=darkhoone_sms_discounts'); ?>" class="button">تنظیمات</a></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php
}

// استایل ویجت
add_action('admin_head', 'darkhoone_dashboard_widgets_styles');
function darkhoone_dashboard_widgets_styles() {
    ?>
    <style>
        .darkhoone-widget { padding: 15px; background: #fff; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .darkhoone-widget p { margin: 8px 0; color: #333; font-size: 14px; }
        .darkhoone-widget strong { color: #0073aa; }
        .darkhoone-about { border-bottom: 2px solid #0073aa; padding-bottom: 15px; margin-bottom: 15px; }
        .darkhoone-tools .darkhoone-tool-item { border-bottom: 1px solid #eee; padding-bottom: 10px; margin-bottom: 10px; }
        .darkhoone-tools .darkhoone-tool-item:last-child { border-bottom: none; }
        .darkhoone-widget .button { background: #0073aa; color: #fff; border: none; padding: 6px 12px; border-radius: 3px; }
        .darkhoone-widget .button:hover { background: #005d87; }
    </style>
    <?php
}

// دیباگ دسترسی‌ها
add_action('admin_init', 'darkhoone_debug_permissions');
function darkhoone_debug_permissions() {
    $user = wp_get_current_user();
    if (in_array('darkhoone_manager', $user->roles)) {
        error_log('User Capabilities: ' . print_r($user->allcaps, true));
    }
}

// ثبت مسیر پنل صندوق‌دار
function darkhoone_register_cashier_endpoint() {
    add_rewrite_rule(
        '^cashier/?$',
        'index.php?cashier_panel=1',
        'top'
    );
}
add_action('init', 'darkhoone_register_cashier_endpoint');

function darkhoone_query_vars($vars) {
    $vars[] = 'cashier_panel';
    return $vars;
}
add_filter('query_vars', 'darkhoone_query_vars');

function darkhoone_render_cashier_panel($template) {
    if (get_query_var('cashier_panel')) {
        error_log('Loading cashier panel - Template: ' . $template);
        if (!is_user_logged_in() || !current_user_can('manage_darkhoone')) {
            error_log('Redirecting to login');
            wp_redirect(wp_login_url(home_url('/cashier')));
            exit;
        }
        $panel_template = plugin_dir_path(__FILE__) . 'templates/cashier-panel.php';
        if (file_exists($panel_template)) {
            error_log('Cashier panel template found at: ' . $panel_template);
            add_filter('show_admin_bar', '__return_false');
            include $panel_template;
            exit;
        } else {
            error_log('Cashier panel template not found at: ' . $panel_template);
        }
    }
    return $template;
}
add_filter('template_include', 'darkhoone_render_cashier_panel', 9999);

// فلاش رول‌ها موقع فعال‌سازی و دیباگ
add_action('admin_init', 'darkhoone_flush_rules_debug');
function darkhoone_flush_rules_debug() {
    if (get_option('darkhoone_flush_needed', 0)) {
        flush_rewrite_rules();
        update_option('darkhoone_flush_needed', 0);
        error_log('Rewrite rules flushed');
    }
}

register_activation_hook(__FILE__, function() {
    darkhoone_register_cashier_endpoint();
    update_option('darkhoone_flush_needed', 1);
    error_log('Plugin activated - Flush needed');
});

// ریدایرکت بعد از لاگین
function darkhoone_login_redirect($redirect_to, $request, $user) {
    if (isset($user->roles) && in_array('darkhoone_manager', $user->roles)) {
        return home_url('/cashier');
    }
    return $redirect_to;
}
add_filter('login_redirect', 'darkhoone_login_redirect', 10, 3);

// چک کردن سفارش جدید با برگرداندن order_id
function darkhoone_check_new_orders() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    error_log('Checking new orders - Nonce received: ' . $nonce);
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in check_new_orders');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }
    $new_order_id = get_option('darkhoone_new_order_pending', false);
    $new_order = $new_order_id ? true : false;
    if ($new_order) {
        delete_option('darkhoone_new_order_pending');
        wp_send_json_success(array('new_order' => $new_order, 'order_id' => $new_order_id));
    } else {
        wp_send_json_success(array('new_order' => $new_order, 'order_id' => ''));
    }
}
add_action('wp_ajax_check_new_orders', 'darkhoone_check_new_orders');

// گرفتن سفارشات در حال پردازش برای AJAX
function darkhoone_get_pending_orders() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in get_pending_orders');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }

    ob_start();
    $args = array(
        'limit' => 20,
        'orderby' => 'date',
        'order' => 'DESC',
        'status' => array_diff(array_keys(wc_get_order_statuses()), array('wc-completed')),
    );
    $orders = wc_get_orders($args);
    if ($orders) {
        echo '<table>';
        echo '<tr><th>شماره سفارش</th><th>تاریخ</th><th>مشتری</th><th>روش تحویل</th><th>جمع کل</th><th>وضعیت</th><th>عملیات</th></tr>';
        foreach ($orders as $order) {
            $order_id = $order->get_id();
            $status = $order->get_status();
            $status_name = wc_get_order_status_name($status);
            $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $delivery_option = get_post_meta($order_id, '_delivery_option', true);
            $delivery_method = $delivery_option === 'pickup' ? 'تحویل حضوری' : ($delivery_option === 'courier' ? 'ارسال با پیک' : 'نامشخص');
            $total = $order->get_total();
            $date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp()) : wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');
            echo '<tr data-order_id="' . $order_id . '">';
            echo '<td><a href="#" class="order-details-link" data-order_id="' . $order_id . '">#' . $order_id . '</a></td>';
            echo '<td>' . esc_html($date) . '</td>';
            echo '<td>' . ($customer_name ?: 'مهمان') . '</td>';
            echo '<td>' . esc_html($delivery_method) . '</td>';
            echo '<td>' . wc_price($total) . '</td>';
            echo '<td class="order-status">' . $status_name . '</td>';
            echo '<td>';
            echo '<select class="order-status-select" data-order_id="' . $order_id . '">';
            $statuses = wc_get_order_statuses();
            foreach ($statuses as $status_key => $status_name_option) {
                $selected = ($status_key === 'wc-' . $status ? 'selected' : '');
                echo '<option value="' . esc_attr($status_key) . '" ' . $selected . '>' . esc_html($status_name_option) . '</option>';
            }
            echo '</select>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</table>';
    } else {
        echo '<p>سفارشی در حال پردازش نیست.</p>';
    }
    $html = ob_get_clean();

    wp_send_json_success(array('html' => $html));
}
add_action('wp_ajax_get_pending_orders', 'darkhoone_get_pending_orders');

// ذخیره محصول با قیمت اصلی و تخفیف جداگانه
function darkhoone_save_product() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    error_log('Saving product - Nonce received: ' . $nonce);
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in save_product');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }

    $product_id = !empty($_POST['product_id']) ? absint($_POST['product_id']) : 0;
    $product_name = sanitize_text_field($_POST['product_name']);
    $product_price = floatval($_POST['product_price']); // قیمت اصلی
    $sale_price = !empty($_POST['product_sale_price']) ? floatval($_POST['product_sale_price']) : ''; // قیمت تخفیف
    $stock = !empty($_POST['product_stock']) ? absint($_POST['product_stock']) : '';
    $category = !empty($_POST['product_category']) ? absint($_POST['product_category']) : '';

    if (!$product_name || !$product_price) {
        wp_send_json_error(array('message' => 'نام و قیمت اصلی اجباری است!'));
    }

    if ($product_id) {
        $product = wc_get_product($product_id);
    } else {
        $product = new WC_Product_Simple();
    }

    $product->set_name($product_name);
    $product->set_regular_price($product_price); // قیمت اصلی
    if ($sale_price !== '' && $sale_price < $product_price) { // فقط اگه تخفیف کمتر از قیمت اصلی باشه
        $product->set_sale_price($sale_price); // قیمت تخفیف
    } else {
        $product->set_sale_price(''); // تخفیف رو حذف کن
    }
    if ($stock !== '') {
        $product->set_manage_stock(true);
        $product->set_stock_quantity($stock);
    } else {
        $product->set_manage_stock(false);
    }
    if ($category) {
        $product->set_category_ids(array($category));
    }

    // آپلود تصویر
    if (!empty($_FILES['product_image']['name'])) {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        $attachment_id = media_handle_upload('product_image', $product_id);
        if (!is_wp_error($attachment_id)) {
            $product->set_image_id($attachment_id);
        } else {
            wp_send_json_error(array('message' => 'خطا در آپلود تصویر: ' . $attachment_id->get_error_message()));
        }
    }

    $product->save();
    wp_send_json_success();
}
add_action('wp_ajax_save_product', 'darkhoone_save_product');

// گرفتن لاگ‌های پیامک از Persian WooCommerce SMS
function darkhoone_get_sms_logs() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in get_sms_logs');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'woocommerce_ir_sms_archive';
    $logs = $wpdb->get_results("SELECT post_id, reciever, message, result, date FROM $table_name ORDER BY date DESC LIMIT 50");

    if ($logs) {
        $formatted_logs = array_map(function($log) {
            $date = strtotime($log->date);
            $persian_date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $date) : date('Y/m/d H:i', $date);
            return array(
                'order_id' => $log->post_id ? $log->post_id : 'نامشخص',
                'reciever' => $log->reciever,
                'message' => $log->message,
                'status' => ($log->result === '_ok_') ? 'ارسال شده' : 'ناموفق',
                'date' => $persian_date
            );
        }, $logs);
        wp_send_json_success(array('logs' => $formatted_logs));
    } else {
        wp_send_json_error(array('message' => 'هیچ پیامکی در آرشیو یافت نشد.'));
    }
}
add_action('wp_ajax_get_sms_logs', 'darkhoone_get_sms_logs');

// گرفتن لاگ‌های اپلیکیشن از جدول wp_appsite_app_logs
function darkhoone_get_app_logs() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    error_log('Getting app logs - Nonce received: ' . $nonce);
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in get_app_logs');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'appsite_app_logs';
    $logs = $wpdb->get_results("SELECT user_imei, device_model, app_version, location, install_date, online_date FROM $table_name ORDER BY online_date DESC LIMIT 50");

    if ($logs) {
        $formatted_logs = array_map(function($log) {
            $install_date = strtotime($log->install_date);
            $online_date = strtotime($log->online_date);
            $persian_install_date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $install_date) : date('Y/m/d H:i', $install_date);
            $persian_online_date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $online_date) : date('Y/m/d H:i', $online_date);
            return array(
                'user_imei' => $log->user_imei,
                'device_model' => $log->device_model,
                'app_version' => $log->app_version,
                'location' => $log->location,
                'install_date' => $persian_install_date,
                'online_date' => $persian_online_date
            );
        }, $logs);
        wp_send_json_success(array('logs' => $formatted_logs));
    } else {
        wp_send_json_error(array('message' => 'هیچ لاگی یافت نشد.'));
    }
}
add_action('wp_ajax_get_app_logs', 'darkhoone_get_app_logs');

// ارسال نوتیفیکیشن با استفاده از تابع Appsite
function darkhoone_send_notification() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    error_log('Sending notification - Nonce received: ' . $nonce);
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        error_log('Nonce verification failed in send_notification');
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
        wp_die();
    }

    $message = sanitize_text_field($_POST['message']);
    if (!$message) {
        wp_send_json_error(array('message' => 'پیام خالی است!'));
        wp_die();
    }

    // فراخوانی تابع ارسال نوتیفیکیشن Appsite
    if (function_exists('appsite_send_notif')) {
        $title = 'اعلان جدید'; // عنوان پیش‌فرض
        $body = $message; // پیام ارسالی از فرم
        $link = home_url(); // لینک پیش‌فرض (می‌تونی تغییرش بدی)
        $topic = 'all'; // تاپیک پیش‌فرض (ممکنه نیاز به تنظیم داشته باشه)

        $result = appsite_send_notif($title, $body, $link, $topic);

        if ($result && isset($result['success']) && $result['success']) {
            wp_send_json_success(array('message' => 'نوتیفیکیشن با موفقیت ارسال شد!'));
        } else {
            wp_send_json_error(array('message' => 'خطا در ارسال نوتیفیکیشن: پاسخ نامعتبر'));
        }
    } else {
        wp_send_json_error(array('message' => 'تابع ارسال نوتیفیکیشن Appsite یافت نشد!'));
    }
}
add_action('wp_ajax_send_notification', 'darkhoone_send_notification');

// ثبت مسیرهای REST API
function darkhoone_register_rest_routes() {
    register_rest_route('darkhoone/v1', '/order_details/(?P<order_id>\d+)', array(
        'methods' => 'POST',
        'callback' => 'darkhoone_get_order_details_rest',
        'permission_callback' => function() {
            return is_user_logged_in() && current_user_can('manage_darkhoone');
        },
        'args' => array(
            'order_id' => array('required' => true),
        ),
    ));

    register_rest_route('darkhoone/v1', '/update_order_status', array(
        'methods' => 'POST',
        'callback' => 'darkhoone_update_order_status_rest',
        'permission_callback' => function() {
            return is_user_logged_in() && current_user_can('manage_darkhoone');
        },
        'args' => array(
            'order_id' => array('required' => true),
            'status' => array('required' => true),
        ),
    ));
}
add_action('rest_api_init', 'darkhoone_register_rest_routes');

function darkhoone_get_order_details_rest($request) {
    $order_id = $request['order_id'];
    error_log('REST API - Get order details for Order ID: ' . $order_id);

    if (!is_numeric($order_id) || $order_id <= 0) {
        return new WP_Error('invalid_order_id', 'شماره سفارش نامعتبر است', array('status' => 400));
    }

    $order = wc_get_order($order_id);
    if (!$order) {
        return new WP_Error('no_order', 'سفارش یافت نشد', array('status' => 404));
    }

    $delivery_option = get_post_meta($order_id, '_delivery_option', true);
    $delivery_method = $delivery_option === 'pickup' ? 'تحویل حضوری' : ($delivery_option === 'courier' ? 'ارسال با پیک' : 'تحویل حضوری');
    $address = $delivery_option === 'courier' ? $order->get_billing_address_1() : '';
    $date = function_exists('pwo_get_persian_date') ? pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp()) : wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');

    ob_start();
    ?>
    <style>
        .order-details-table { width: 100%; border-collapse: collapse; font-size: 14px; direction: rtl; margin-bottom: 15px; }
        .order-details-table th, .order-details-table td { padding: 8px; border: 1px solid #000; text-align: right; }
        .order-details-table th { background: #f1f1f1; }
        .order-items-table { width: 100%; border-collapse: collapse; font-size: 14px; direction: rtl; }
        .order-items-table th, .order-items-table td { padding: 8px; border: 1px solid #000; text-align: right; }
        .order-items-table th { background: #f1f1f1; }
        .order-number { text-align: center; margin-bottom: 10px; font-size: 16px; }
        @media print {
            .order-details-table, .order-items-table { width: 80mm; font-family: 'Tahoma', sans-serif; font-size: 12px; }
            .order-number { position: absolute; top: 0; right: 0; font-size: 14px; }
            .modal-content { border: none; box-shadow: none; }
            #print-order-btn { display: none; }
        }
    </style>
    <div class="order-number">سفارش #<?php echo $order_id; ?></div>
    <table class="order-details-table">
        <tr>
            <th>تاریخ</th>
            <td><?php echo esc_html($date); ?></td>
        </tr>
        <tr>
            <th>مشتری</th>
            <td><?php echo esc_html($order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ?: 'مهمان'); ?></td>
        </tr>
        <tr>
            <th>شماره موبایل</th>
            <td><?php echo $order->get_billing_phone() ? esc_html($order->get_billing_phone()) : 'ثبت نشده'; ?></td>
        </tr>
        <tr>
            <th>روش تحویل</th>
            <td><?php echo esc_html($delivery_method); ?></td>
        </tr>
        <?php if ($address) { ?>
        <tr>
            <th>آدرس</th>
            <td><?php echo esc_html($address); ?></td>
        </tr>
        <?php } ?>
        <tr>
            <th>جمع کل</th>
            <td><?php echo wc_price($order->get_total()); ?></td>
        </tr>
    </table>
    <table class="order-items-table">
        <thead>
            <tr>
                <th>محصول</th>
                <th>تعداد</th>
                <th>قیمت</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($order->get_items() as $item) {
                $product = $item->get_product();
                $quantity = $item->get_quantity();
                $total = $item->get_total();
                ?>
                <tr>
                    <td><?php echo esc_html($product->get_name()); ?></td>
                    <td><?php echo esc_html($quantity); ?></td>
                    <td><?php echo wc_price($total); ?></td>
                </tr>
                <?php
            }
            ?>
        </tbody>
    </table>
    <?php
    $content = ob_get_clean();

    error_log('REST API - Order details retrieved successfully for order: ' . $order_id);
    return rest_ensure_response(array('content' => $content));
}

function darkhoone_update_order_status_rest($request) {
    $order_id = $request['order_id'];
    $status = $request['status'];
    error_log('REST API - Update order status - Order ID: ' . $order_id . ', Status: ' . $status);

    $order = wc_get_order($order_id);
    if (!$order) {
        return new WP_Error('no_order', 'سفارش یافت نشد', array('status' => 404));
    }

    $order->update_status(str_replace('wc-', '', $status), 'تغییر وضعیت از پنل صندوق‌دار');
    $new_status_name = wc_get_order_status_name(str_replace('wc-', '', $status));
    error_log('REST API - Order status updated: ' . $order_id . ' to ' . $status);

    return rest_ensure_response(array(
        'message' => 'وضعیت سفارش به‌روزرسانی شد!',
        'status_name' => $new_status_name
    ));
}

// ذخیره تنظیمات عمومی
function darkhoone_save_settings() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
    }
    $modules = isset($_POST['darkhoone_modules']) ? array_map('sanitize_text_field', $_POST['darkhoone_modules']) : [];
    update_option('darkhoone_modules', $modules);
    wp_send_json_success();
}
add_action('wp_ajax_save_settings', 'darkhoone_save_settings');

// بارگذاری ساعت‌های سفارش
function darkhoone_load_order_hours() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
    }
    $options = get_option('darkhoone_order_hours_options', [
        'enabled' => '0',
        'morning_start' => '11:00',
        'morning_end' => '15:00',
        'evening_start' => '19:00',
        'evening_end' => '23:00',
        'cart_message' => 'سبد خرید در حال حاضر غیرفعال است.',
        'checkout_message' => 'سفارش فقط در ساعات مجاز امکان‌پذیر است.',
        'front_message' => 'توجه: سفارش فقط در ساعات مجاز امکان‌پذیر است.'
    ]);
    wp_send_json_success($options);
}
add_action('wp_ajax_load_order_hours', 'darkhoone_load_order_hours');

// ذخیره ساعت‌های سفارش
function darkhoone_save_order_hours() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
    }
    $options = array(
        'enabled' => isset($_POST['enabled']) ? 1 : 0,
        'morning_start' => sanitize_text_field($_POST['morning_start']),
        'morning_end' => sanitize_text_field($_POST['morning_end']),
        'evening_start' => sanitize_text_field($_POST['evening_start']),
        'evening_end' => sanitize_text_field($_POST['evening_end']),
        'cart_message' => sanitize_textarea_field($_POST['cart_message']),
        'checkout_message' => sanitize_textarea_field($_POST['checkout_message']),
        'front_message' => sanitize_textarea_field($_POST['front_message'])
    );
    update_option('darkhoone_order_hours_options', $options);
    wp_send_json_success();
}
add_action('wp_ajax_save_order_hours', 'darkhoone_save_order_hours');

// بارگذاری پیامک تخفیف
function darkhoone_load_sms_discounts() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
    }
    $data = [
        'discount_percentage' => get_option('darkhoone_sd_discount_percentage', 10),
        'expiry_days' => get_option('darkhoone_sd_expiry_days', 7),
        'sms_message' => get_option('darkhoone_sd_sms_message', 'ممنون از خریدتون! کد تخفیف {percentage}%: {coupon_code} - اعتبار {expiry_days} روز')
    ];
    wp_send_json_success($data);
}
add_action('wp_ajax_load_sms_discounts', 'darkhoone_load_sms_discounts');

// ذخیره پیامک تخفیف
function darkhoone_save_sms_discounts() {
    $nonce = isset($_POST['nonce']) ? sanitize_text_field($_POST['nonce']) : '';
    if (!wp_verify_nonce($nonce, 'darkhoone_nonce')) {
        wp_send_json_error(array('message' => 'خطای امنیتی!'));
    }
    update_option('darkhoone_sd_discount_percentage', absint($_POST['discount_percentage']));
    update_option('darkhoone_sd_expiry_days', absint($_POST['expiry_days']));
    update_option('darkhoone_sd_sms_message', sanitize_textarea_field($_POST['sms_message']));
    wp_send_json_success();
}
add_action('wp_ajax_save_sms_discounts', 'darkhoone_save_sms_discounts');

?>