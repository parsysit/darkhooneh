<?php
if (!defined('ABSPATH')) {
    exit;
}

if (darkhoone_is_module_active('simple_dashboard')) {
    // بررسی فعال بودن ووکامرس
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return;
    }

    // رندر صفحه پیشخوان
    function darkhoone_sd_render_simple_dashboard() {
        ?>
        <div class="wrap">
            <h1>پیشخوان ساده سفارشات</h1>
            <table class="wp-list-table widefat fixed striped" id="simple-orders-table">
                <thead>
                    <tr>
                        <th>شماره سفارش</th>
                        <th>تاریخ</th>
                        <th>مشتری</th>
                        <th>روش تحویل</th>
                        <th>جمع کل</th>
                        <th>وضعیت</th>
                        <th>عملیات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $args = array(
                        'limit' => 20,
                        'orderby' => 'date',
                        'order' => 'DESC',
                        'status' => array_keys(array_diff_key(wc_get_order_statuses(), array('wc-completed' => ''))),
                    );
                    $orders = wc_get_orders($args);

                    foreach ($orders as $order) {
                        $order_id = $order->get_id();
                        $status = $order->get_status();
                        $status_name = wc_get_order_status_name($status);
                        $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
                        $delivery_option = get_post_meta($order_id, '_delivery_option', true);
                        $delivery_method = 'نامشخص';
                        if ($delivery_option === 'pickup') {
                            $delivery_method = 'تحویل حضوری';
                        } elseif ($delivery_option === 'courier') {
                            $delivery_method = 'ارسال با پیک';
                        }
                        $total = $order->get_total();
                        $date = wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');
                        if (function_exists('pwo_get_persian_date')) {
                            $date = pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp());
                        }
                        ?>
                        <tr data-order_id="<?php echo $order_id; ?>">
                            <td><a href="#" class="order-details-link" data-order_id="<?php echo $order_id; ?>">#<?php echo $order_id; ?></a></td>
                            <td><?php echo esc_html($date); ?></td>
                            <td><?php echo $customer_name ?: 'مهمان'; ?></td>
                            <td><?php echo esc_html($delivery_method); ?></td>
                            <td><?php echo wc_price($total); ?></td>
                            <td><?php echo $status_name; ?></td>
                            <td>
                                <select class="order-status-select" data-order_id="<?php echo $order_id; ?>">
                                    <?php
                                    $statuses = wc_get_order_statuses();
                                    foreach ($statuses as $status_key => $status_name_option) {
                                        $selected = ($status_key === 'wc-' . $status ? 'selected' : '');
                                        echo '<option value="' . esc_attr($status_key) . '" ' . $selected . '>' . esc_html($status_name_option) . '</option>';
                                    }
                                    ?>
                                </select>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>

            <!-- مودال -->
            <div id="order-details-modal" class="modal">
                <div class="modal-content">
                    <span class="close-modal">×</span>
                    <div id="order-details-content"></div>
                    <button id="print-order-btn" class="button">پرینت</button>
                </div>
            </div>
        </div>
        <?php
    }

    // اضافه کردن اسکریپت و استایل
    add_action('admin_enqueue_scripts', 'darkhoone_sd_enqueue_simple_dashboard_scripts');
    function darkhoone_sd_enqueue_simple_dashboard_scripts($hook) {
        if (strpos($hook, 'darkhoone_simple_dashboard') === false) {
            return;
        }

        error_log('Loading scripts for hook: ' . $hook);

        wp_enqueue_script(
            'darkhoone-simple-dashboard-js',
            plugin_dir_url(__DIR__) . 'assets/js/simple-dashboard.js',
            array('jquery'),
            '1.9',
            true
        );
        wp_enqueue_style(
            'darkhoone-simple-dashboard-css',
            plugin_dir_url(__DIR__) . 'assets/css/simple-dashboard.css',
            array(),
            '1.9'
        );
        wp_localize_script('darkhoone-simple-dashboard-js', 'simpleDashboard', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('update_order_status'),
            'refresh_nonce' => wp_create_nonce('refresh_orders'),
            'details_nonce' => wp_create_nonce('get_order_details'),
        ));
    }

    // هندل کردن تغییر وضعیت با AJAX
    add_action('wp_ajax_update_order_status', 'darkhoone_sd_update_order_status_callback');
    function darkhoone_sd_update_order_status_callback() {
        check_ajax_referer('update_order_status', 'nonce');

        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        $status = isset($_POST['status']) ? sanitize_text_field($_POST['status']) : '';

        if ($order_id && $status) {
            $order = wc_get_order($order_id);
            if ($order) {
                $order->update_status($status, 'تغییر وضعیت از پیشخوان ساده');
                $new_status_name = wc_get_order_status_name(str_replace('wc-', '', $status));
                wp_send_json_success(array(
                    'message' => 'وضعیت سفارش به‌روزرسانی شد!',
                    'status_name' => $new_status_name,
                    'is_completed' => ($status === 'wc-completed')
                ));
            } else {
                wp_send_json_error(array('message' => 'سفارش یافت نشد!'));
            }
        } else {
            wp_send_json_error(array('message' => 'اطلاعات نامعتبر!'));
        }

        wp_die();
    }

    // هندل کردن رفرش سفارشات با AJAX
    add_action('wp_ajax_refresh_orders', 'darkhoone_sd_refresh_orders_callback');
    function darkhoone_sd_refresh_orders_callback() {
        check_ajax_referer('refresh_orders', 'nonce');

        $args = array(
            'limit' => 20,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_keys(array_diff_key(wc_get_order_statuses(), array('wc-completed' => ''))),
        );
        $orders = wc_get_orders($args);

        ob_start();
        foreach ($orders as $order) {
            $order_id = $order->get_id();
            $status = $order->get_status();
            $status_name = wc_get_order_status_name($status);
            $customer_name = $order->get_billing_first_name() . ' ' . $order->get_billing_last_name();
            $delivery_option = get_post_meta($order_id, '_delivery_option', true);
            $delivery_method = 'نامشخص';
            if ($delivery_option === 'pickup') {
                $delivery_method = 'تحویل حضوری';
            } elseif ($delivery_option === 'courier') {
                $delivery_method = 'ارسال با پیک';
            }
            $total = $order->get_total();
            $date = wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');
            if (function_exists('pwo_get_persian_date')) {
                $date = pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp());
            }
            ?>
            <tr data-order_id="<?php echo $order_id; ?>">
                <td><a href="#" class="order-details-link" data-order_id="<?php echo $order_id; ?>">#<?php echo $order_id; ?></a></td>
                <td><?php echo esc_html($date); ?></td>
                <td><?php echo $customer_name ?: 'مهمان'; ?></td>
                <td><?php echo esc_html($delivery_method); ?></td>
                <td><?php echo wc_price($total); ?></td>
                <td><?php echo $status_name; ?></td>
                <td>
                    <select class="order-status-select" data-order_id="<?php echo $order_id; ?>">
                        <?php
                        $statuses = wc_get_order_statuses();
                        foreach ($statuses as $status_key => $status_name_option) {
                            $selected = ($status_key === 'wc-' . $status ? 'selected' : '');
                            echo '<option value="' . esc_attr($status_key) . '" ' . $selected . '>' . esc_html($status_name_option) . '</option>';
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <?php
        }
        $table_content = ob_get_clean();

        wp_send_json_success(array('table_content' => $table_content));
        wp_die();
    }

    // هندل کردن جزئیات سفارش با AJAX
    add_action('wp_ajax_get_order_details', 'darkhoone_sd_get_order_details_callback');
    function darkhoone_sd_get_order_details_callback() {
        check_ajax_referer('get_order_details', 'nonce');

        $order_id = isset($_POST['order_id']) ? absint($_POST['order_id']) : 0;
        if (!$order_id) {
            wp_send_json_error(array('message' => 'سفارش نامعتبر!'));
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_send_json_error(array('message' => 'سفارش یافت نشد!'));
        }

        $delivery_option = get_post_meta($order_id, '_delivery_option', true);
        $delivery_method = 'نامشخص';
        if ($delivery_option === 'pickup') {
            $delivery_method = 'تحویل حضوری';
        } elseif ($delivery_option === 'courier') {
            $delivery_method = 'ارسال با پیک';
        }
        $address = $delivery_option === 'courier' ? $order->get_billing_address_1() : '';
        $date = wc_format_datetime($order->get_date_created(), 'Y/m/d H:i');
        if (function_exists('pwo_get_persian_date')) {
            $date = pwo_get_persian_date('Y/m/d H:i', $order->get_date_created()->getTimestamp());
        }

        ob_start();
        ?>
        <style>
            .order-details-table { width: 100%; border-collapse: collapse; font-size: 14px; direction: rtl; }
            .order-details-table th, .order-details-table td { padding: 5px; border: 1px solid #000; text-align: right; }
            .order-details-table th { background: #f1f1f1; }
            .order-items-table { width: 100%; border-collapse: collapse; font-size: 12px; direction: rtl; margin-top: 10px; }
            .order-items-table th, .order-items-table td { padding: 3px; border: 1px solid #000; text-align: right; }
            .order-number { text-align: center; margin-bottom: 10px; }
            @media print {
                .order-details-table, .order-items-table { width: 80mm; font-family: 'Tahoma', sans-serif; }
                .order-number { position: absolute; top: 0; right: 0; font-size: 14px; }
                .modal-content { border: none; box-shadow: none; position: relative; }
                #print-order-btn, .close-modal { display: none; }
            }
        </style>
        <div class="order-number">سفارش #<?php echo $order_id; ?></div>
        <table class="order-details-table">
            <tr>
                <th>تاریخ</th>
                <td><?php echo esc_html($date); ?></td>
            </tr>
            <tr>
                <th>مشتری</th>
                <td><?php echo $order->get_billing_first_name() . ' ' . $order->get_billing_last_name() ?: 'مهمان'; ?></td>
            </tr>
            <tr>
                <th>شماره موبایل</th>
                <td><?php echo $order->get_billing_phone() ? esc_html($order->get_billing_phone()) : 'ثبت نشده'; ?></td>
            </tr>
            <tr>
                <th>روش تحویل</th>
                <td><?php echo esc_html($delivery_method); ?></td>
            </tr>
            <?php if ($address) { ?>
            <tr>
                <th>آدرس</th>
                <td><?php echo esc_html($address); ?></td>
            </tr>
            <?php } ?>
            <tr>
                <th>جمع کل</th>
                <td><?php echo wc_price($order->get_total()); ?></td>
            </tr>
        </table>
        <table class="order-items-table">
            <thead>
                <tr>
                    <th>محصول</th>
                    <th>تعداد</th>
                    <th>قیمت</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($order->get_items() as $item) {
                    $product = $item->get_product();
                    $quantity = $item->get_quantity();
                    $total = $item->get_total();
                    ?>
                    <tr>
                        <td><?php echo esc_html($product->get_name()); ?></td>
                        <td><?php echo $quantity; ?></td>
                        <td><?php echo wc_price($total); ?></td>
                    </tr>
                    <?php
                }
                ?>
            </tbody>
        </table>
        <?php
        $content = ob_get_clean();

        wp_send_json_success(array('content' => $content));
        wp_die();
    }
}