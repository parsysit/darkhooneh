<?php
if (!defined('ABSPATH')) {
    exit;
}

if (darkhoone_is_module_active('new_order_notification')) {
    // بررسی فعال بودن ووکامرس
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return;
    }

    // ثبت سفارش جدید و ذخیره فلگ
    add_action('woocommerce_new_order', 'darkhoone_non_flag_new_order', 10, 1);
    function darkhoone_non_flag_new_order($order_id) {
        update_option('darkhoone_new_order_pending', $order_id);
    }

    // اضافه کردن اسکریپت و استایل به پیشخوان
    add_action('admin_enqueue_scripts', 'darkhoone_non_enqueue_new_order_notification');
    function darkhoone_non_enqueue_new_order_notification() {
        if (!is_admin()) {
            return;
        }

        wp_enqueue_script(
            'darkhoone-new-order-notif',
            plugin_dir_url(__DIR__) . 'assets/js/new-order-notification.js',
            array('jquery'),
            '1.1',
            true
        );
        wp_enqueue_style(
            'darkhoone-new-order-notif-style',
            plugin_dir_url(__DIR__) . 'assets/css/new-order-notification.css',
            array(),
            '1.1'
        );

        $new_order_id = get_option('darkhoone_new_order_pending', false);
        wp_localize_script('darkhoone-new-order-notif', 'newOrderData', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'new_order_id' => $new_order_id ? absint($new_order_id) : 0,
        ));

        if ($new_order_id) {
            delete_option('darkhoone_new_order_pending');
        }
    }

    // چک کردن سفارش جدید با AJAX
    add_action('wp_ajax_check_new_order', 'darkhoone_non_check_new_order_callback');
    function darkhoone_non_check_new_order_callback() {
        $new_order_id = get_option('darkhoone_new_order_pending', false);
        if ($new_order_id && $new_order_id > 0) {
            wp_send_json_success(array(
                'order_id' => absint($new_order_id),
                'message' => sprintf('سفارش جدید با شماره %s ثبت شد!', $new_order_id)
            ));
            delete_option('darkhoone_new_order_pending');
        } else {
            wp_send_json_error(array('message' => 'سفارش جدیدی نیست'));
        }
        wp_die();
    }
}