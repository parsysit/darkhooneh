<?php
if (!defined('ABSPATH')) {
    exit;
}

if (darkhoone_is_module_active('order_hours')) {
    // بررسی فعال بودن ووکامرس
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return;
    }

    // ثبت تنظیمات
    add_action('admin_init', 'darkhoone_oh_order_hours_register_settings');
    function darkhoone_oh_order_hours_register_settings() {
        register_setting('darkhoone_oh_settings', 'darkhoone_order_hours_options', 'darkhoone_oh_order_hours_sanitize_options');
        add_settings_section('oh_main_section', 'تنظیمات اصلی', null, 'darkhoone_order_hours');
        add_settings_field('enabled', 'فعال کردن محدودیت', 'darkhoone_oh_order_hours_enabled_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('morning_start', 'شروع بازه صبح', 'darkhoone_oh_order_hours_morning_start_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('morning_end', 'پایان بازه صبح', 'darkhoone_oh_order_hours_morning_end_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('evening_start', 'شروع بازه عصر', 'darkhoone_oh_order_hours_evening_start_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('evening_end', 'پایان بازه عصر', 'darkhoone_oh_order_hours_evening_end_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('cart_message', 'پیام سبد خرید', 'darkhoone_oh_order_hours_cart_message_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('checkout_message', 'پیام تسویه حساب', 'darkhoone_oh_order_hours_checkout_message_field', 'darkhoone_order_hours', 'oh_main_section');
        add_settings_field('front_message', 'پیام صفحه اصلی', 'darkhoone_oh_order_hours_front_message_field', 'darkhoone_order_hours', 'oh_main_section');
    }

    function darkhoone_oh_order_hours_enabled_field() {
        $options = get_option('darkhoone_order_hours_options', array('enabled' => '0'));
        echo '<input type="checkbox" name="darkhoone_order_hours_options[enabled]" value="1" ' . checked(1, $options['enabled'], false) . ' />';
    }

    function darkhoone_oh_order_hours_morning_start_field() {
        $options = get_option('darkhoone_order_hours_options', array('morning_start' => '11:00'));
        echo '<input type="time" name="darkhoone_order_hours_options[morning_start]" value="' . esc_attr($options['morning_start']) . '" />';
    }

    function darkhoone_oh_order_hours_morning_end_field() {
        $options = get_option('darkhoone_order_hours_options', array('morning_end' => '15:00'));
        echo '<input type="time" name="darkhoone_order_hours_options[morning_end]" value="' . esc_attr($options['morning_end']) . '" />';
    }

    function darkhoone_oh_order_hours_evening_start_field() {
        $options = get_option('darkhoone_order_hours_options', array('evening_start' => '19:00'));
        echo '<input type="time" name="darkhoone_order_hours_options[evening_start]" value="' . esc_attr($options['evening_start']) . '" />';
    }

    function darkhoone_oh_order_hours_evening_end_field() {
        $options = get_option('darkhoone_order_hours_options', array('evening_end' => '23:00'));
        echo '<input type="time" name="darkhoone_order_hours_options[evening_end]" value="' . esc_attr($options['evening_end']) . '" />';
    }

    function darkhoone_oh_order_hours_cart_message_field() {
        $options = get_option('darkhoone_order_hours_options', array('cart_message' => 'سبد خرید در حال حاضر غیرفعال است. سفارش فقط در ساعات مجاز امکان‌پذیر است.'));
        echo '<textarea name="darkhoone_order_hours_options[cart_message]" rows="3" cols="50">' . esc_textarea($options['cart_message']) . '</textarea>';
    }

    function darkhoone_oh_order_hours_checkout_message_field() {
        $options = get_option('darkhoone_order_hours_options', array('checkout_message' => 'سفارش فقط در ساعات مجاز امکان‌پذیر است. لطفاً در زمان مجاز اقدام کنید.'));
        echo '<textarea name="darkhoone_order_hours_options[checkout_message]" rows="3" cols="50">' . esc_textarea($options['checkout_message']) . '</textarea>';
    }

    function darkhoone_oh_order_hours_front_message_field() {
        $options = get_option('darkhoone_order_hours_options', array('front_message' => 'توجه: سفارش فقط در ساعات مجاز امکان‌پذیر است.'));
        echo '<textarea name="darkhoone_order_hours_options[front_message]" rows="3" cols="50">' . esc_textarea($options['front_message']) . '</textarea>';
    }

    function darkhoone_oh_order_hours_sanitize_options($input) {
        $sanitized = array();
        $sanitized['enabled'] = isset($input['enabled']) ? 1 : 0;
        $sanitized['morning_start'] = sanitize_text_field($input['morning_start']);
        $sanitized['morning_end'] = sanitize_text_field($input['morning_end']);
        $sanitized['evening_start'] = sanitize_text_field($input['evening_start']);
        $sanitized['evening_end'] = sanitize_text_field($input['evening_end']);
        $sanitized['cart_message'] = sanitize_textarea_field($input['cart_message']);
        $sanitized['checkout_message'] = sanitize_textarea_field($input['checkout_message']);
        $sanitized['front_message'] = sanitize_textarea_field($input['front_message']);
        return $sanitized;
    }

    function darkhoone_oh_order_hours_settings_page() {
        ?>
        <div class="wrap">
            <h1>تنظیمات ساعت‌های سفارش</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('darkhoone_oh_settings');
                do_settings_sections('darkhoone_order_hours');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    function darkhoone_oh_is_time_allowed() {
        $options = get_option('darkhoone_order_hours_options', array(
            'enabled' => '0',
            'morning_start' => '11:00',
            'morning_end' => '15:00',
            'evening_start' => '19:00',
            'evening_end' => '23:00'
        ));

        if (!$options['enabled']) {
            return true;
        }

        $timezone = wp_timezone_string();
        date_default_timezone_set($timezone);

        $current_time = (int)date('H') + ((int)date('i') / 60);

        list($morning_start_h, $morning_start_m) = explode(':', $options['morning_start']);
        list($morning_end_h, $morning_end_m) = explode(':', $options['morning_end']);
        list($evening_start_h, $evening_start_m) = explode(':', $options['evening_start']);
        list($evening_end_h, $evening_end_m) = explode(':', $options['evening_end']);

        $morning_start = (int)$morning_start_h + ((int)$morning_start_m / 60);
        $morning_end = (int)$morning_end_h + ((int)$morning_end_m / 60);
        $evening_start = (int)$evening_start_h + ((int)$evening_start_m / 60);
        $evening_end = (int)$evening_end_h + ((int)$evening_end_m / 60);

        return ($current_time >= $morning_start && $current_time <= $morning_end) ||
               ($current_time >= $evening_start && $current_time <= $evening_end);
    }

    add_filter('woocommerce_is_purchasable', 'darkhoone_oh_disable_cart_outside_hours', 10, 2);
    function darkhoone_oh_disable_cart_outside_hours($purchasable, $product) {
        if (!darkhoone_oh_is_time_allowed()) {
            return false;
        }
        return $purchasable;
    }

    add_action('woocommerce_before_cart', 'darkhoone_oh_display_cart_disabled_notice');
    function darkhoone_oh_display_cart_disabled_notice() {
        if (!darkhoone_oh_is_time_allowed()) {
            $options = get_option('darkhoone_order_hours_options');
            wc_print_notice($options['cart_message'], 'error');
        }
    }

    add_action('woocommerce_checkout_process', 'darkhoone_oh_restrict_order_hours');
    function darkhoone_oh_restrict_order_hours() {
        if (!darkhoone_oh_is_time_allowed()) {
            $options = get_option('darkhoone_order_hours_options');
            wc_add_notice($options['checkout_message'], 'error');
        }
    }

    add_action('wp_body_open', 'darkhoone_oh_display_order_hours_front_page');
    function darkhoone_oh_display_order_hours_front_page() {
        if (is_front_page() && !darkhoone_oh_is_time_allowed()) {
            $options = get_option('darkhoone_order_hours_options');
            $hours = sprintf(
                '%s تا %s و %s تا %s',
                $options['morning_start'],
                $options['morning_end'],
                $options['evening_start'],
                $options['evening_end']
            );
            $message = $options['front_message'] . ' (' . $hours . ')';
            echo '<div style="background-color: #f8d7da; color: #721c24; padding: 15px; text-align: center; font-size: 16px; margin: 0; border-bottom: 1px solid #f5c6cb;">';
            echo esc_html($message);
            echo '</div>';
        }
    }
}