<?php
// جلوگیری از دسترسی مستقیم (اختیاری توی ماژول، چون فایل اصلی چک می‌کنه)
if (!defined('ABSPATH')) {
    exit;
}

if (darkhoone_is_module_active('delivery_options')) {
    // بررسی فعال بودن ووکامرس
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return;
    }

    // غیرفعال کردن روش‌های حمل و نقل پیش‌فرض ووکامرس
    add_filter('woocommerce_shipping_methods', '__return_empty_array');
    add_filter('woocommerce_cart_needs_shipping', '__return_false');
    add_filter('woocommerce_cart_needs_shipping_address', '__return_false');

    // اضافه کردن گزینه‌های تحویل
    add_filter('woocommerce_checkout_fields', 'darkhoone_do_add_delivery_options', 10);
    function darkhoone_do_add_delivery_options($fields) {
        $fields['billing']['delivery_option'] = array(
            'type'     => 'radio',
            'label'    => __('روش تحویل', 'woocommerce'),
            'required' => true,
            'class'    => array('form-row-wide'),
            'options'  => array(
                'pickup'  => __('تحویل حضوری', 'woocommerce'),
                'courier' => __('ارسال با پیک', 'woocommerce'),
            ),
            'default'  => 'pickup',
            'priority' => 10,
        );
        return $fields;
    }

    // شخصی‌سازی فیلدهای تسویه‌حساب
    add_filter('woocommerce_checkout_fields', 'darkhoone_do_customize_checkout_fields', 20);
    function darkhoone_do_customize_checkout_fields($fields) {
        // حذف فیلدهای غیرضروری
        unset($fields['billing']['billing_company']);
        unset($fields['billing']['billing_address_2']);
        unset($fields['billing']['billing_city']);
        unset($fields['billing']['billing_state']);
        unset($fields['billing']['billing_postcode']);
        unset($fields['billing']['billing_country']);
        unset($fields['billing']['billing_email']);

        // تنظیم فیلدها
        $fields['billing']['billing_first_name']['required'] = true;
        $fields['billing']['billing_last_name']['required'] = true;
        $fields['billing']['billing_phone']['required'] = true;
        
        // تنظیم فیلد آدرس با لیبل ثابت
        $fields['billing']['billing_address_1']['label'] = __('آدرس (اجباری)', 'woocommerce');
        $fields['billing']['billing_address_1']['required'] = false; // پیش‌فرض اختیاری، توی حالت پیک اجباری می‌شه
        $fields['billing']['billing_address_1']['label_class'] = array('darkhoone-do-address-label');

        // گرفتن اطلاعات از پروفایل کاربر
        if (is_user_logged_in()) {
            $user_id = get_current_user_id();
            $fields['billing']['billing_first_name']['default'] = get_user_meta($user_id, 'billing_first_name', true);
            $fields['billing']['billing_last_name']['default'] = get_user_meta($user_id, 'billing_last_name', true);
            $fields['billing']['billing_phone']['default'] = get_user_meta($user_id, 'billing_phone', true);
            $fields['billing']['billing_address_1']['default'] = get_user_meta($user_id, 'billing_address_1', true);
        }

        return $fields;
    }

    // حذف "(اختیاری)" از لیبل آدرس
    add_filter('woocommerce_form_field', 'darkhoone_do_remove_optional_from_address_label', 10, 4);
    function darkhoone_do_remove_optional_from_address_label($field, $key, $args, $value) {
        if ($key === 'billing_address_1') {
            $field = preg_replace('/<span class="optional">\(اختیاری\)<\/span>/', '', $field);
        }
        return $field;
    }

    // حذف کامل ایمیل
    add_filter('woocommerce_checkout_posted_data', 'darkhoone_do_remove_email_from_checkout_data');
    function darkhoone_do_remove_email_from_checkout_data($data) {
        unset($data['billing_email']);
        return $data;
    }

    add_filter('woocommerce_checkout_required_fields', 'darkhoone_do_remove_email_from_required_fields', 10, 1);
    function darkhoone_do_remove_email_from_required_fields($required_fields) {
        unset($required_fields['billing_email']);
        return $required_fields;
    }

    add_filter('woocommerce_checkout_get_value', 'darkhoone_do_remove_email_default_value', 10, 2);
    function darkhoone_do_remove_email_default_value($value, $input) {
        if ($input === 'billing_email') {
            return null;
        }
        return $value;
    }

    add_action('woocommerce_checkout_update_order_meta', 'darkhoone_do_remove_email_from_order_meta', 20);
    function darkhoone_do_remove_email_from_order_meta($order_id) {
        update_post_meta($order_id, '_billing_email', '');
    }

    // مدیریت آدرس بر اساس گزینه تحویل
    add_filter('woocommerce_checkout_fields', 'darkhoone_do_dynamic_address_requirement', 30);
    function darkhoone_do_dynamic_address_requirement($fields) {
        if (isset($_POST['delivery_option']) && $_POST['delivery_option'] === 'pickup') {
            $fields['billing']['billing_address_1']['required'] = false;
        } elseif (isset($_POST['delivery_option']) && $_POST['delivery_option'] === 'courier') {
            $fields['billing']['billing_address_1']['required'] = true;
        }
        return $fields;
    }

    // غیرفعال کردن نیاز به آدرس برای تحویل حضوری
    add_filter('woocommerce_cart_needs_shipping_address', 'darkhoone_do_disable_shipping_address_for_pickup');
    function darkhoone_do_disable_shipping_address_for_pickup($needs_address) {
        if (isset($_POST['delivery_option']) && $_POST['delivery_option'] === 'pickup') {
            return false;
        }
        return $needs_address;
    }

    add_action('woocommerce_checkout_process', 'darkhoone_do_force_disable_address_validation_for_pickup');
    function darkhoone_do_force_disable_address_validation_for_pickup() {
        if (isset($_POST['delivery_option']) && $_POST['delivery_option'] === 'pickup') {
            add_filter('woocommerce_checkout_required_field_notice', function($notice, $field_key) {
                if ($field_key === 'billing_address_1') {
                    return '';
                }
                return $notice;
            }, 10, 2);

            $_POST['billing_address_1'] = 'تحویل حضوری';
        }
    }

    // ذخیره گزینه تحویل
    add_action('woocommerce_checkout_update_order_meta', 'darkhoone_do_save_delivery_option');
    function darkhoone_do_save_delivery_option($order_id) {
        if (!empty($_POST['delivery_option'])) {
            update_post_meta($order_id, '_delivery_option', sanitize_text_field($_POST['delivery_option']));
            if ($_POST['delivery_option'] === 'pickup') {
                update_post_meta($order_id, '_billing_address_1', 'تحویل حضوری');
            }
        }
    }

    // اسکریپت جاوااسکریپت برای تغییر پویا
    add_action('wp_footer', 'darkhoone_do_checkout_field_toggle_script');
    function darkhoone_do_checkout_field_toggle_script() {
        if (is_checkout()) {
            $user_address = '';
            if (is_user_logged_in()) {
                $user_id = get_current_user_id();
                $user_address = get_user_meta($user_id, 'billing_address_1', true);
                if ($user_address === 'تحویل حضوری' || empty($user_address)) {
                    $user_address = '';
                }
            }
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function($) {
                    $('#billing_address_1_field').hide();

                    function updateAddressField() {
                        var selectedOption = $('input[name="delivery_option"]:checked').val();
                        if (!selectedOption) {
                            $('input[name="delivery_option"][value="pickup"]').prop('checked', true);
                            selectedOption = 'pickup';
                        }

                        if (selectedOption === 'pickup') {
                            $('#billing_address_1_field').slideUp();
                            $('#billing_address_1').prop('required', false).val('تحویل حضوری');
                        } else if (selectedOption === 'courier') {
                            $('#billing_address_1_field').slideDown();
                            $('#billing_address_1').prop('required', true);
                            var savedAddress = '<?php echo esc_js($user_address); ?>';
                            if (savedAddress && $('#billing_address_1').val() !== savedAddress) {
                                $('#billing_address_1').val(savedAddress);
                            } else if (!savedAddress && $('#billing_address_1').val() === 'تحویل حضوری') {
                                $('#billing_address_1').val('');
                            }
                        }
                    }

                    $('input[name="delivery_option"]').on('change', function() {
                        updateAddressField();
                    });

                    updateAddressField();
                });
            </script>
            <?php
        }
    }
}