<?php
if (!defined('ABSPATH')) {
    exit;
}

if (darkhoone_is_module_active('sms_discounts')) {
    // بررسی فعال بودن ووکامرس
    if (!in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
        return;
    }

    // صفحه تنظیمات
    function darkhoone_sd_settings_page() {
        ?>
        <div class="wrap">
            <h1>تنظیمات پیامک تخفیف</h1>
            <form method="post" action="options.php">
                <?php
                settings_fields('darkhoone_sd_settings_group');
                do_settings_sections('darkhoone_sms_discounts');
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    // ثبت تنظیمات
    add_action('admin_init', 'darkhoone_sd_register_settings');
    function darkhoone_sd_register_settings() {
        register_setting('darkhoone_sd_settings_group', 'darkhoone_sd_discount_percentage');
        register_setting('darkhoone_sd_settings_group', 'darkhoone_sd_expiry_days');
        register_setting('darkhoone_sd_settings_group', 'darkhoone_sd_sms_message');

        add_settings_section(
            'darkhoone_sd_main_section',
            'تنظیمات اصلی',
            null,
            'darkhoone_sms_discounts'
        );

        add_settings_field(
            'darkhoone_sd_discount_percentage',
            'درصد تخفیف',
            'darkhoone_sd_discount_percentage_callback',
            'darkhoone_sms_discounts',
            'darkhoone_sd_main_section'
        );

        add_settings_field(
            'darkhoone_sd_expiry_days',
            'مدت اعتبار (روز)',
            'darkhoone_sd_expiry_days_callback',
            'darkhoone_sms_discounts',
            'darkhoone_sd_main_section'
        );

        add_settings_field(
            'darkhoone_sd_sms_message',
            'متن پیامک',
            'darkhoone_sd_sms_message_callback',
            'darkhoone_sms_discounts',
            'darkhoone_sd_main_section'
        );
    }

    function darkhoone_sd_discount_percentage_callback() {
        $value = get_option('darkhoone_sd_discount_percentage', 10);
        echo '<input type="number" name="darkhoone_sd_discount_percentage" value="' . esc_attr($value) . '" min="1" max="100" /> %';
    }

    function darkhoone_sd_expiry_days_callback() {
        $value = get_option('darkhoone_sd_expiry_days', 7);
        echo '<input type="number" name="darkhoone_sd_expiry_days" value="' . esc_attr($value) . '" min="1" /> روز';
    }

    function darkhoone_sd_sms_message_callback() {
        $value = get_option('darkhoone_sd_sms_message', 'ممنون از خریدتون از درخونه! کد تخفیف {percentage}% برای خرید بعدی شما: {coupon_code} - اعتبار کد فقط {expiry_days} روزه!');
        echo '<textarea name="darkhoone_sd_sms_message" rows="5" cols="50">' . esc_textarea($value) . '</textarea>';
        echo '<p>متغیرها: {coupon_code} برای کد تخفیف، {percentage} برای درصد، {expiry_days} برای مدت اعتبار</p>';
    }

    // ارسال پیامک تخفیف بعد از تکمیل سفارش
    add_action('woocommerce_order_status_completed', 'darkhoone_sd_send_discount_code_after_purchase', 20, 1);
    function darkhoone_sd_send_discount_code_after_purchase($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            error_log("سفارش $order_id پیدا نشد!");
            return;
        }

        $phone = $order->get_billing_phone();
        if (empty($phone)) {
            error_log("شماره تلفن برای سفارش $order_id خالی است!");
            return;
        }

        if (substr($phone, 0, 3) === '+98') {
            $phone = '0' . substr($phone, 3);
        }
        error_log("شماره تلفن تبدیل‌شده برای سفارش $order_id: $phone");

        $coupon_code = '';
        $attempts = 0;
        $max_attempts = 10;

        do {
            $coupon_code = rand(10000, 99999);
            $existing_coupon = new WC_Coupon($coupon_code);
            $attempts++;
        } while ($existing_coupon->get_id() && $attempts < $max_attempts);

        if ($attempts >= $max_attempts) {
            error_log("نمی‌توان کد تخفیف 5 رقمی منحصربه‌فرد برای سفارش $order_id پیدا کرد!");
            return;
        }

        $discount_amount = get_option('darkhoone_sd_discount_percentage', 10);
        $expiry_days = get_option('darkhoone_sd_expiry_days', 7);

        $coupon = new WC_Coupon();
        $coupon->set_code($coupon_code);
        $coupon->set_discount_type('percent');
        $coupon->set_amount($discount_amount);
        $coupon->set_usage_limit(1);
        $coupon->set_date_expires(strtotime("+$expiry_days days"));

        $new_coupon_id = $coupon->save();
        if (!$new_coupon_id) {
            error_log("خطا در ساخت کد تخفیف برای سفارش $order_id");
            return;
        }

        $message_template = get_option('darkhoone_sd_sms_message', 'ممنون از خریدتون از درخونه! کد تخفیف {percentage}% برای خرید بعدی شما: {coupon_code} - اعتبار کد فقط {expiry_days} روزه!');
        $message = str_replace(
            ['{coupon_code}', '{percentage}', '{expiry_days}'],
            [$coupon_code, $discount_amount, $expiry_days],
            $message_template
        );
        error_log("پیام در حال ارسال: $message به شماره: $phone");

        if (function_exists('PWSMS')) {
            $sms_helper = PWSMS();
            $gateway = $sms_helper->get_option('sms_gateway');
            
            if ($gateway && $gateway === 'PW\PWSMS\Gateways\SunwaySMS') {
                $data = [
                    'mobile'  => $phone,
                    'message' => $message,
                    'post_id' => $order_id
                ];

                $result = $sms_helper->send_sms($data);
                if ($result === true) {
                    error_log("پیامک برای سفارش $order_id با موفقیت ارسال شد به شماره: $phone");
                } else {
                    error_log("خطای ارسال پیامک برای سفارش $order_id - شماره: $phone - نتیجه: " . print_r($result, true));
                }
            } else {
                error_log("درگاه پیامک SunwaySMS نیست یا تنظیم نشده است. درگاه فعلی: $gateway");
            }
        } else {
            error_log("تابع PWSMS() برای سفارش $order_id پیدا نشد");
        }
    }
}